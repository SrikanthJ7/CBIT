var subb = document.getElementById("sub");
var opt1 = document.getElementById("Option-1");
opt1.onclick = function() {
    var year1 = document.getElementById("Option1");
    year1.onclick = function() {
        function myfunction() {
            var image = document.getElementById("Image");
            image.setAttribute("src", "immages/img1.jpeg");
        }
    }
    
        var year2 = document.getElementById("Option2");
        year2.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/vc-1.jpg");
        }
    
        var year3 = document.getElementById("Option3");
        year3.onclick = function() {
            var img = document.getElementById("Image");
           img.setAttribute("src","immages/viic-11.jpg");
        }
    
    }
    
    var opt2 = document.getElementById("Option-2");
    opt2.onclick = function() {
        var year1 = document.getElementById("Option1");
        year1.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/img2.jpeg");
        }
    
        var year2 = document.getElementById("Option2");
        year2.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/vc-2.jpg");
        }
    
        var year3 = document.getElementById("Option3");
        year3.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/viic-2.jpg");
        }
    
    }
    
    var opt3 = document.getElementById("Option-3");
    opt3.onclick = function() {
        var year1 = document.getElementById("Option1");
        year1.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/img3.jpeg");
        }
    
        var year2 = document.getElementById("Option2");
        year2.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/vc-3.jpg");
        }
    
        var year3 = document.getElementById("Option3");
        year3.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/vii-3.jpg");
        }
    
       
    }
    
    var opt4 = document.getElementById("Option-4");
    opt4.onclick = function() {
        var year1 = document.getElementById("Option1");
        year1.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/img4.jpeg");
        }
    
        var year2 = document.getElementById("Option2");
        year2.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/vc-4.jpg");
        }
    
        var year3 = document.getElementById("Option3");
        year3.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/img6.jpeg");
        }
    
    
    }
    
    var opt5 = document.getElementById("Option-5");
    opt5.onclick = function() {
        var year1 = document.getElementById("Option1");
        year1.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/img5.jpeg");
        }
    
        var year2 = document.getElementById("Option2");
        year2.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/vc-5.jpg");
        }
    
        var year3 = document.getElementById("Option3");
        year3.onclick = function() {
            var img = document.getElementById("Image");
            img.setAttribute("src","immages/img6.jpeg");
        }
    
        
    }
             
